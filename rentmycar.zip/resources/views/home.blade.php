"
<section><h3>Similar Vehicles</h3>
    <ul class="similar-listings__ul">
        <li data-href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-qwr0zk">
            <div class="first"
                 style="background-image:url(https://vimg.cheki.co.ke/m/1_inventory1818995_1542615469.jpg)">
                <div class="similar-listings__checkbox-container"><input name="listingId[]" value="1818995"
                                                                         type="checkbox"
                                                                         class="similar-listings__checkbox"
                                                                         checked="checked"></div>
                <a href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-qwr0zk"></a></div>
            <div class="second">
                <div class="similar-listings__title">Mercedes-Benz E200</div>
                <div class="similar-listings__location">Mombasa</div>
                <div class="similar-listings__price"><span>KSh</span>2,400,000</div>
            </div>
        </li>
        <li data-href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-v9j5xv">
            <div class="first"
                 style="background-image:url(https://vimg.cheki.co.ke/m/1_inventory1816202_1542260399.jpg)">
                <div class="similar-listings__checkbox-container"><input name="listingId[]" value="1816202"
                                                                         type="checkbox"
                                                                         class="similar-listings__checkbox"
                                                                         checked="checked"></div>
                <a href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-v9j5xv"></a></div>
            <div class="second">
                <div class="similar-listings__title">Mercedes-Benz E200</div>
                <div class="similar-listings__location">Nairobi</div>
                <div class="similar-listings__price"><span>KSh</span>3,600,000</div>
            </div>
        </li>
        <li data-href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-g46w68">
            <div class="first"
                 style="background-image:url(https://vimg.cheki.co.ke/m/1_inventory1812457_1541684868.jpg)">
                <div class="similar-listings__checkbox-container"><input name="listingId[]" value="1812457"
                                                                         type="checkbox"
                                                                         class="similar-listings__checkbox"
                                                                         checked="checked"></div>
                <a href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-g46w68"></a></div>
            <div class="second">
                <div class="similar-listings__title">Mercedes-Benz E200</div>
                <div class="similar-listings__location">Nairobi</div>
                <div class="similar-listings__price"><span>KSh</span>3,000,000</div>
            </div>
        </li>
        <li data-href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-5rqgn2">
            <div class="first"
                 style="background-image:url(https://vimg.cheki.co.ke/m/1_inventory1793563_1539606994.jpg)">
                <div class="similar-listings__checkbox-container"><input name="listingId[]" value="1793563"
                                                                         type="checkbox"
                                                                         class="similar-listings__checkbox"
                                                                         checked="checked"></div>
                <a href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-5rqgn2"></a></div>
            <div class="second">
                <div class="similar-listings__title">Mercedes-Benz E200</div>
                <div class="similar-listings__location">Nairobi</div>
                <div class="similar-listings__price"><span>KSh</span>2,890,000</div>
            </div>
        </li>
        <li data-href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-epm975">
            <div class="first"
                 style="background-image:url(https://vimg.cheki.co.ke/m/1_inventory1781364_1535357502.jpg)">
                <div class="similar-listings__checkbox-container"><input name="listingId[]" value="1781364"
                                                                         type="checkbox"
                                                                         class="similar-listings__checkbox"
                                                                         checked="checked"></div>
                <a href="https://www.cheki.co.ke/vehicle/mercedes-benz-e200-epm975"></a></div>
            <div class="second">
                <div class="similar-listings__title">Mercedes-Benz E200</div>
                <div class="similar-listings__location">Nairobi</div>
                <div class="similar-listings__price"><span>KSh</span>2,499,999</div>
            </div>
        </li>
    </ul>
</section>"