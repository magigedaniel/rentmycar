<!--footer section start-->
<footer>
    <p> &copy; <?php echo date('Y');?> RentMyCar.co.ke</p>

</footer>
