<?php
/**
 * Created by PhpStorm.
 * User: DMagige
 * Date: 10/27/2016
 * Time: 10:53 AM
 */
?>

<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Designed by  <a href="//magigedaniel.com" target="_blank">Magige Daniel</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo date('Y');?> <a href="#">RentMyCar.co.ke</a>.</strong> All rights reserved.
</footer>
