
<!--footer section start-->
<footer>
    <p>&copy 2016 - 2017 Daystar Film Festival. All Rights Reserved</p>
</footer>