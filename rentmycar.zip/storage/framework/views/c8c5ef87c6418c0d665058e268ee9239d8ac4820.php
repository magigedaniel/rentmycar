<!--footer section start-->
<footer>
    <p> &copy; <?php echo date('Y');?> EASFF. <span style="float: right">BY:<a
                    style="color: red;background:white;font-weight:bold;" href="#" > Magigedaniel</a></span></p>

</footer>
