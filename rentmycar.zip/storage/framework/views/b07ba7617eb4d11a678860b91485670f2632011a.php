<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
    <head>
        <title>RentMyCar.co.ke | <?php echo $video->title; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="keywords" content="RentMyCar.co.ke"/>


        <meta property="og:url"           content="https://deasff.com/mypost?video=<?php echo e($video->id); ?>" />
        <meta property="og:type"          content="website" />
        <meta property="og:title"         content="East Africa Student Film Festival" />
        <meta property="og:description"   content="DEASFF is an annual event bringing together student film makers from the East Africa region for competion on films" />
        <meta property="og:image"         content="https://deasff.com/<?php echo $video->imageurl; ?>" />



        <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
            }, false);
            function hideURLbar() {
            window.scrollTo(0, 1);
            } </script>
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
        <!-- Custom CSS -->
        <link href="css/style.css" rel='stylesheet' type='text/css'/>
        <!-- Graph CSS -->
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- jQuery -->
        <!-- lined-icons -->
        <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
        <!-- //lined-icons -->
        <!-- Meters graphs -->
        <script src="js/jquery-2.1.4.js"></script>


    </head>

    <style>
        div#page-wrapper {
            padding: 0 10% 0 10%;
        }
    </style>
    <!-- /w3layouts-agile -->
    <body class="sticky-header left-side-collapsed">
        <section>
            <!-- left side start-->
            <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /w3layouts-agile -->
            <!-- app-->
            <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog facebook" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <div class="app-grids">
                                <div class="app">
                                    <div class="col-md-5 app-left mpl">
                                        <h3>DayStarFilm mobile app on your smartphone!</h3>
                                        <p>Download and Avail Special Songs Videos and Audios.</p>
                                        <div class="app-devices">
                                            <h5>Gets the app from</h5>
                                            <a href="#"><img src="images/1.png" alt=""></a>
                                            <a href="#"><img src="images/2.png" alt=""></a>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 app-image">
                                        <img src="images/apps.png" alt="">
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //app-->
            <!-- /w3l-agile -->
            <!-- signup -->
            <?php echo $__env->make('modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- //signup -->
            <!-- /w3l-agile -->
            <!-- left side end-->
            <!-- main content start-->
            <div class="container">
                <!-- header-starts -->
                <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <!--notification menu end -->
                <!-- //header-ends -->
                <!-- /w3l-agileits -->
                <!-- //header-ends -->

                <div id="page-wrapper" style="">
                    <div class="inner-content single">
                        <!--/music-right-->

                        <div class="single_left"><!--/video-main-->
<!--                            <iframe width="100%" height="345px" src="<?php echo e($video->videoUrl); ?>?html5=1" allowfullscreen=""
                                    frameborder="0">
                            </iframe>-->
                             <iframe width="100%" height="345px" frameborder="0" allowfullscreen
                                     src="<?php echo e($video->videoUrl); ?>?autoplay=1">
                             </iframe> 
                            <div></div>
                            <div class="alert alert-info fade in">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                Video Category: <?php echo e($video->category); ?>

                            </div>
                            <!-- script for play-list -->

                            <!-- //script for play-list -->
                            <!--//video-main-->
                            <!-- /agileinfo -->
                            <div class="row">
                                <div class="col-xs-3">
                                    <a href="#" target="_blank">
                                        <!--<button type="button" class="btn btn-primary btn-sm"><span class="fa fa-share"> Share</span></button>-->
                                        <div class="fb-share-button" data-href="https://deasff.com/mypost?video=<?php echo e($video->id); ?>" data-layout="button_count" data-size="small" data-mobile-iframe="true">
                                            <a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdeasff.com%2Fmypost%3Fvideo%3D<?php echo e($video->id); ?>&amp;src=sdkpreparse">
                                                <button type="button" class="btn btn-primary btn-sm"><span class="fa fa-share"> Share</span></button>
                                            </a>
                                        </div>
                                    </a>
                                </div>
                                <?php if($current_year.'' == $video->year.''): ?> 
                                
                                <div class="col-xs-9">
                                    <?php if($user_voted): ?>
                                    <button type="button" class="btn btn-success btn-sm"><span class="fa fa-check-square"> Thank you! you voted this category</span></button>
                                    <?php else: ?>
                                    <a href="vote?video=<?php echo $video->id; ?>">
                                        <button type="button" class="btn btn-danger btn-sm"><span class="fa fa-check-circle-o"> Click To Vote</span></button>
                                    </a>
                                    <?php endif; ?> 
                                </div>
                                
                                <?php endif; ?>
                            </div> 
                        </div>
                        <div class="response">
                            <h4><?php echo $video->title; ?></h4>
                            <div class="media response-info">
                                <div class="media-body response-text-right">
                                    <?php echo $video->content; ?>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <!-- /agileits -->
                        <!--//music-right-->
                        <?php echo $__env->make('slidervideo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <!--body wrapper start-->


                </div>
                <div class="clearfix"></div>
                <!--body wrapper end-->
                <!-- /w3l-agile -->
            </div>
            <!--body wrapper end-->
            <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!--footer section end-->
            <!-- /w3l-agile -->
            <!-- main content end-->
        </section>

        <script src="js/jquery.nicescroll.js"></script>
        <script src="js/scripts.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.js"></script>
    </body>
</html>
