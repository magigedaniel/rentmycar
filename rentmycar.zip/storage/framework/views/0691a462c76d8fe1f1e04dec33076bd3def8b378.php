<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>About: Daystar East Africa Student Film Festival</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="js/jquery-2.1.4.js"></script>


</head>
<!-- /w3layouts-agile -->
<style>
    div#page-wrapper{
        padding: 0 3% 0 2%;
    }
</style>
<body class="sticky-header left-side-collapsed" onload="initMap()">
<section>
    <!-- left side start-->
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /w3layouts-agile -->
    <!-- app-->

    <!-- //app-->
    <!-- /w3l-agile -->
    <!-- signup -->
<?php echo $__env->make('modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //signup -->
    <!-- /w3l-agile -->
    <!-- left side end-->
    <!-- main content start-->
    <div class="main-content">
        <!-- header-starts -->
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--notification menu end -->
        <!-- //header-ends -->
        <!-- /w3l-agileits -->
        <!-- //header-ends -->

        <div id="page-wrapper" style="">
            <div class="inner-content single">
                <p style="float:none; text-align: center;"><strong>FESTIVAL INFORMATION</strong></p>
                <p><strong>&nbsp;</strong></p>
                <p><strong>About Us</strong></p>
                <p><strong>The East Africa Student Film Festival </strong>is an annual event organized by Daystar University, Kenya to offer student filmmakers across East Africa an exclusive prospect to not only interact with their peers but also gain the recognition of industry practitioners and other stakeholders. The festival will provide a forum for student filmmakers to showcase their films in various categories.</p>
                <p>&nbsp;</p>
                <p>The festival is <strong>open to</strong> <strong>students only</strong>. <strong>The participants should be pursuing their undergraduate or postgraduate studies at a recognized University (Public or Private) or Film School</strong>. High school students may however be invited to participate in the future. For more information please read &ldquo;<u>Terms and Conditions</u>&rdquo;.</p>
                <p>&nbsp;</p>
                <p><strong>Our Vision</strong></p>
                <p>East Africa&rsquo;s film industry has witnessed exponential growth over the last few years. This has created the need for new and creative talent to further boost the growth of the industry. We therefore seek to bridge the gap between the creative industry and academia by nurturing and celebrating promising, creative student talent from institutions of higher learning.</p>
                <p>&nbsp;</p>
                <p><strong>Funding</strong></p>
                <p>The festival is an annual event, currently organized by Daystar University in partnership with Kenya Film Classification Board (KFCB), The Kenya Film Commission (KFC) and Performers Rights Society of Kenya (PRiSK) among other Stakeholders in the TV and Film Industry. The East Africa Student Film Festival is a non-profit organization that depends on Corporate sponsorships, non-corporate donations, private donors, and foundations interested in supporting the arts. There are currently <strong><u>No Entry fees</u> </strong>associated with the festival.</p>
                <p>&nbsp;</p>
                <p>Sales of general merchandise including but not limited to T-shirts, bags and other items pertaining to the festival&rsquo;s promotion and advertisement are anticipated to supplement funding. The festival will be promoted widely across the region.</p>
                <p>&nbsp;</p>
                <p><strong>Location</strong></p>
                <p><strong>The East Africa Student Film Festival, 2017 </strong>is scheduled for its first ever presentation at Daystar University, Nairobi Campus, Valley Road.</p>
                <p>&nbsp;</p>
                <p><strong>Categories</strong></p>
                <p>Students will submit their films or videos to the festival for competition or non-competition. For the competition, the following categories will apply:</p>
                <p>&nbsp;</p>
                <ul>
                    <li><strong>Feature length films</strong></li>
                    <li><strong>Short films</strong></li>
                    <li><strong>Documentary films</strong></li>
                    <li><strong>Smart-phone productions</strong></li>
                </ul>
                <p>For more information, please see <u>Submissions</u>.</p>
                <p>&nbsp;</p>
                <p><strong>The Jury</strong></p>
                <p>All films will be subjected to <strong><u>public voting</u></strong><u>,</u> (see <u>Voting</u>), which will account for 50% of the total evaluation. The remaining 50% will be decided by the <strong>Jury<em>, </em></strong>which will constitute dedicated professionals that may include film lecturers, filmmakers, writers, directors, producers, actors, distributors, agents, film critics and journalists.</p>
                <p>&nbsp;</p>
                <p><strong>The Awards</strong></p>
                <p>Awards will be announced at the closing ceremony. See <u>Selection criteria</u> for more information.</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p>
                <!-- /agileits -->
                <!--//music-right-->
                

            </div>
            <!--body wrapper start-->


        </div>
        <div class="clearfix"></div>
        <!--body wrapper end-->
        <!-- /w3l-agile -->
    </div>
    <!--body wrapper end-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.js"></script>
</body>
</html>