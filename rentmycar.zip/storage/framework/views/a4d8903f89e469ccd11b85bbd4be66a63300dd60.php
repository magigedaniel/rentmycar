<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
    <head>
        <title>RentMyCar.co.ke | Archives</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="keywords" content="RentMyCar.co.ke"/>
        <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
            }, false);
            function hideURLbar() {
            window.scrollTo(0, 1);
            } </script>
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
        <!-- Custom CSS -->
        <link href="css/style.css" rel='stylesheet' type='text/css'/>
        <!-- Graph CSS -->
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- jQuery -->
        <!-- lined-icons -->
        <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
        <!-- //lined-icons -->
        <!-- Meters graphs -->
        <script src="js/jquery-2.1.4.js"></script>

    </head>

    <!-- /w3layouts-agile -->
    <body class="sticky-header left-side-collapsed">
        <section>
            <!-- left side start-->
            
            <!-- /w3layouts-agile -->
            <!-- app-->
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!-- //app-->
            <!-- /w3l-agile -->
            <!-- signup -->

            <!-- //signup -->
            <!-- /w3l-agile -->
            <!-- left side end-->
            <!-- main content start-->
            <!--<div class="main-content" style="">-->
            <div class="container" style="">
                <div style="" class="border-all">
                    <!-- header-starts -->
                    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!--notification menu end -->
                    <!-- //header-ends -->
                    <!-- /w3l-agileits -->
                    <!-- //header-ends -->
                    <div id="page-wrapper" style="padding: 2%;">
                        <div class="inner-content single">
                            <h2 style="text-align: center; font-weight: 900;">Previous Video Posts</h2>
                            <hr style="color: black; height: 2px">
                            <div class="post">
                                <!-- /.user-block -->
                                <?php 
                                $ipaddress = '';
                                if (isset($_SERVER['HTTP_CLIENT_IP']))
                                $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
                                else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
                                $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                                else if(isset($_SERVER['HTTP_X_FORWARDED']))
                                $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
                                else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
                                $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
                                else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
                                $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
                                else if(isset($_SERVER['HTTP_FORWARDED']))
                                $ipaddress = $_SERVER['HTTP_FORWARDED'];
                                else if(isset($_SERVER['REMOTE_ADDR']))
                                $ipaddress = $_SERVER['REMOTE_ADDR'];
                                else
                                $ipaddress = 'UNKNOWN';

                                 ?>
                                <div class="row "> 
                                    <?php for($i=1; $i<= count($video_archive_array);): ?>
                                    <?php 
                                    $video_archive1 = $video_archive_array[$i];
                                    if(($i+1)<=count($video_archive_array))
                                    $video_archive2 = $video_archive_array[$i+1];
                                    if(($i+2)<=count($video_archive_array))
                                    $video_archive3 = $video_archive_array[$i+2];
                                     ?>                                 
                                    <div class="row">
                                        <div class="col-md-4">
                                            <!--<div class="caption">-->
                                                <h5 class="text-black text-sm" style="font-weight: 800; text-align: center"><?php echo e($video_archive1->title); ?></h5>
                                            <!--</div>-->
                                            <div class="thumbnail">
                                                <a href="<?php echo '/mypost?video='. $video_archive1->id.'&id='.$ipaddress; ?>" target="_blank">
                                                    <img id="image<?php echo e($video_archive1->id); ?>" src="<?php echo $video_archive1->imageurl; ?>"  title="Click to Play" style="width:100%;" onmouseover="showVideo('<?php echo e($video_archive1->id); ?>')">
<!--                                                    <iframe width="100%" height="345px" src="<?php echo e($video_archive1->videoUrl); ?>?html5=1" allowfullscreen=""
                                                            frameborder="0" style="display: none" id="video<?php echo e($video_archive1->id); ?>">
                                                    </iframe>-->
                                                    <!--<div class="caption">-->
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <a href="<?php echo '/mypost?video='. $video_archive1->id.'&id='.$ipaddress; ?>" target="_blank">
                                                                    <button type="button" class="btn btn-success btn-sm" style="width: 100%"><span class="fa fa-play-circle"> Click to play now</span></button>
                                                                </a>
                                                            </div>
                                                        </div> 
                                                    <!--</div>-->
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <!--<div class="caption">-->
                                                <h5 class="text-black text-sm" style="font-weight: 800; text-align: center"><?php echo e($video_archive2->title); ?></h5>
                                            <!--</div>-->
                                            <div class="thumbnail">
                                                <a href="<?php echo '/mypost?video='. $video_archive2->id.'&id='.$ipaddress; ?>" target="_blank">
                                                    <img src="<?php echo $video_archive2->imageurl; ?>"  title="Click to Play" style="width:100%">
<!--                                                    <iframe width="100%" height="345px" src="<?php echo e($video_archive2->videoUrl); ?>?html5=1" allowfullscreen=""
                                                            frameborder="0">
                                                    </iframe>-->
                                                    <!--<div class="caption">-->
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <a href="<?php echo '/mypost?video='. $video_archive2->id.'&id='.$ipaddress; ?>" target="_blank">
                                                                    <button type="button" class="btn btn-success btn-sm" style="width: 100%"><span class="fa fa-play-circle"> Click to play now</span></button>
                                                                </a>
                                                            </div>
                                                        </div> 
                                                    <!--</div>-->
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <!--<div class="caption">-->
                                                <h5 class="text-black text-sm" style="font-weight: 800; text-align: center"><?php echo e($video_archive3->title); ?></h5>
                                            <!--</div>-->
                                            <div class="thumbnail">
                                                <a href="<?php echo '/mypost?video='. $video_archive3->id.'&id='.$ipaddress; ?>" target="_blank">
                                                    <img src="<?php echo $video_archive3->imageurl; ?>"  title="Click to Play" style="width:100%">
<!--                                                    <iframe width="100%" height="345px" src="<?php echo e($video_archive3->videoUrl); ?>?html5=1" allowfullscreen=""
                                                            frameborder="0">
                                                    </iframe>-->
                                                    <!--<div class="caption" >-->
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <a href="<?php echo '/mypost?video='. $video_archive3->id.'&id='.$ipaddress; ?>" target="_blank">
                                                                    <button type="button" class="btn btn-success btn-sm" style="width: 100%"><span class="fa fa-play-circle"> Click to play now</span></button>
                                                                </a>
                                                            </div>
                                                        </div> 
                                                    <!--</div>-->
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    $i+=3;
                                     ?>
                                    <?php endfor; ?>
                                </div>
                                <ul class="pagination">
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                </ul>
                            </div>
                            <!--body wrapper start-->
                        </div>
                        <div class="clearfix"></div>
                        <!--body wrapper end-->
                        <!-- /w3l-agile -->

                        <?php echo $__env->make('sponsor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div>

                            <div class="tittle-head">
                                <h3 class="tittle" style="text-align: center; margin-left: 35%;">Our Map Location</h3>
                                <div class="clearfix"></div>
                            </div>
                            <div class="clearfix"></div>
                            <div style="position: relative;">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1677.0819840144175!2d36.801393712555836!3d-1.297289714971404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f109521a475dd%3A0xb5070814ceb91e88!2sDaystar+University%2C+Nairobi+Campus!5e0!3m2!1sen!2ske!4v1485554800953"
                                        width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
                <!--body wrapper end-->

                <!--footer section end-->
                <!-- /w3l-agile -->
                <!-- main content end-->
        </section>

        <script src="js/jquery.nicescroll.js"></script>
        <script src="js/scripts.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.js"></script>
    </body>
<script>
function showVideo(video_id) {
    var video = document.getElementById(video_id);
    var image = document.getElementById(video_id);
    video.style.display = 'block';
    image.style.display = 'none';
}

function onYouTubePlayerAPIReady() {

}
    </script>
</html>



