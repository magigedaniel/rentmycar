<?php
/**
 * Created by PhpStorm.
 * User: DMagige
 * Date: 10/27/2016
 * Time: 10:53 AM
 */
?>

<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Powered by  <a href="#">BC</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2016 <a href="#">Company Name</a>.</strong> All rights reserved.
</footer>