<!--footer section start-->
<footer>
    <p> &copy; <?php echo date('Y');?> RentMyCar.co.ke <span style="float: right">BY:<a
                    style="color: red;background:white;font-weight:bold;" href="#" > rentmycar</a></span></p>

</footer>
