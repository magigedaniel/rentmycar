
<div class="header-section">
    <style>
        .menu{
            margin-left: 5%;
            color: #ffffff;
            font-size: 16px;
            font-weight: bold;
        }
    </style>
    <!--toggle button start-->
    
    <!--toggle button end-->
    <!--notification menu start -->
    <div class="menu-right">
        <div class="profile_details">
  
            <!-- search-scripts -->
        
            <!-- //search-scripts -->
            <!---->
            <div >

                <!---->
                <!--audio-->
                <!---->


                <!--//-->
                
                    

                
                <div >
                    <a href="/" class="menu pull-left"><img src="images/logo.png" style="float: left;"></a>
                    <a href="/" class="menu">Home</a>
                    <a href="/NewPost" class="menu">Submission</a>
                    <a href="/about" class="menu">About</a>
                    <a href="" class="menu">Archive</a>
                    <a href="" class="menu">Blog</a>
                    <a href="/support" class="menu">Support & Partner</a>
                    <a href="" class="menu">Contact</a>
                    <a href="/faq" class="menu">FAQ</a>
                    <?php if(!empty($user->fname)): ?>
                    <?php if($user->usertype == "admin"): ?>
                        <a href="/admin" class="menu">Admin</a>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div id="loginpop" class="pull-right">
                        <?php if(!empty($user->fname)): ?>
                            <a href="<?php echo e(url('/logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
                               class="" style="color: whitesmoke;" title="Click to Log out">
                                Log out(<?php echo $user->fname; ?>)</a>
                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        <?php else: ?>
                            <a href="/login" id="" >
                                <span style="">Login <i class="arrow glyphicon glyphicon-chevron-right"></i></span></a>
                        <?php endif; ?>
                    </div>
                </div>


            </div>

        </div>
        <!-------->
    </div>
</div>