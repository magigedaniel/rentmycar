<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>DayStar RentMyCar.co.ke | Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="js/jquery-2.1.4.js"></script>


</head>

<style>
    div#page-wrapper {
        padding: 0 2% 0 2%;
    }
</style>

<!-- /w3layouts-agile -->
<body class="sticky-header left-side-collapsed">
<section>
    <!-- left side start-->
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /w3layouts-agile -->
    <!-- app-->



























<!-- //app-->
    <!-- /w3l-agile -->
    <!-- signup -->
<?php echo $__env->make('modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //signup -->
    <!-- /w3l-agile -->
    <!-- left side end-->
    <!-- main content start-->
    <div class="main-content">
        <!-- header-starts -->
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--notification menu end -->
        <!-- //header-ends -->
        <!-- /w3l-agileits -->
        <!-- //header-ends -->
        <div id="page-wrapper">
            <div class="inner-content">

                <div class="music-left">
                    <!--banner-section-->
                    <div class="banner-section">
                        <div class="banner">
                            <div class="callbacks_container">
                                <ul class="rslides callbacks callbacks1" id="slider4">
                                    <li>
                                        <div class="banner-img">
                                            <img src="images/1.jpg" class="img-responsive" alt="">
                                        </div>
                                        
                                        
                                        
                                        
                                        

                                    </li>
                                    <li>
                                        <div class="banner-img">
                                            <img src="images/2.jpg" class="img-responsive" alt="">
                                        </div>
                                        
                                        
                                        
                                        
                                        


                                    </li>
                                    <li>
                                        <div class="banner-img">
                                            <img src="images/3.jpg" class="img-responsive" alt="">
                                        </div>
                                    
                                    
                                    
                                    
                                    

                                    <!-- /w3layouts-agileits -->
                                    </li>
                                    <li>
                                        <div class="banner-img">
                                            <img src="images/4.jpg" class="img-responsive" alt="">
                                        </div>
                                    
                                    
                                    
                                    
                                    

                                    <!-- /w3layouts-agileits -->
                                    </li>
                                </ul>
                            </div>
                            <!--banner-->
                            <script src="js/responsiveslides.min.js"></script>
                            <script>
                                // You can also use "$(window).load(function() {"
                                $(function () {
                                    // Slideshow 4
                                    $("#slider4").responsiveSlides({
                                        auto: true,
                                        pager: true,
                                        nav: true,
                                        speed: 500,
                                        namespace: "callbacks",
                                        before: function () {
                                            $('.events').append("<li>before event fired.</li>");
                                        },
                                        after: function () {
                                            $('.events').append("<li>after event fired.</li>");
                                        }
                                    });

                                });
                            </script>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <!--//End-banner-->
                    <!--albums-->
                    <!-- pop-up-box -->
                    <link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all">
                    <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
                    <script>
                        $(document).ready(function () {
                            $('.popup-with-zoom-anim').magnificPopup({
                                type: 'inline',
                                fixedContentPos: false,
                                fixedBgPos: true,
                                overflowY: 'auto',
                                closeBtnInside: true,
                                preloader: false,
                                midClick: true,
                                removalDelay: 300,
                                mainClass: 'my-mfp-zoom-in'
                            });
                        });
                    </script>
                    <!--//pop-up-box -->
                    <div class="albums">


                        <div class="tittle-head">
                            <h3 class="tittle">Countdown</h3>
                            <div class="clearfix"></div>
                        </div>

                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vides): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col-md-3 content-grid last-grid">
                                <a href="<?php echo '/mypost?video='. $vides->id; ?>"><img src="<?php echo $vides->imageurl; ?>"
                                                                                  title="Click to Play"><i
                                            class="fa fa-play"></i></a>
                                <div class="inner-info"><a href="<?php echo '/mypost?video='. $vides->id; ?>">
                                        <h5><?php echo e($vides->title); ?></h5></a></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                        <div class="col-md-3 content-grid">
                            <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><img src="images/v2.jpg"
                                                                                                title="allbum-name"></a>

                            <a class="button play-icon popup-with-zoom-anim" href="#small-dialog">Listen now</a>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><img src="images/v3.jpg"
                                                                                                title="allbum-name"></a>

                            <a class="button play-icon popup-with-zoom-anim" href="#small-dialog">Listen now</a>
                        </div>
                        <div class="col-md-3 content-grid last-grid">
                            <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><img src="images/v4.jpg"
                                                                                                title="allbum-name"></a>

                            <a class="button play-icon popup-with-zoom-anim" href="#small-dialog">Listen now</a>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><img src="images/v5.jpg"
                                                                                                title="allbum-name"></a>

                            <a class="button play-icon popup-with-zoom-anim" href="#small-dialog">Listen now</a>
                        </div>

                        <div class="col-md-3 content-grid">
                            <a class="play-icon popup-with-zoom-anim" href="#small-dialog"><img src="images/v6.jpg"
                                                                                                title="allbum-name"></a>

                            <a class="button play-icon popup-with-zoom-anim" href="#small-dialog">Listen now</a>
                        </div>

                        <div class="clearfix"></div>
                    </div>
                    <!--//End-albums-->
                    <!--//discover-view-->

                    <div class="albums second">
                        <div class="tittle-head">
                            <h3 class="tittle">Submissions</h3>
                            <div class="clearfix"></div>
                        </div>


                        <div class="col-md-3 content-grid">
                            <a href=""><img src="images/v11.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a href=""><img src="images/v22.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a href=""><img src="images/v33.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid last-grid">
                            <a href=""><img src="images/v44.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a href=""><img src="images/v55.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a href=""><img src="images/v66.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid">
                            <a href=""><img src="images/v11.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="col-md-3 content-grid last-grid">
                            <a href=""><img src="images/v22.jpg" title="allbum-name"></a>
                            <div class="inner-info"><a href=""><h5>Pop</h5></a></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <!--//discover-view-->
                </div>
                <!--//music-left-->
                <!--/music-right-->
                <div class="music-right">
                    <div style="max-height: 620px; overflow: scroll;">
                        <a class="twitter-timeline" href="https://twitter.com/TwitterDev">Tweets by TwitterDev</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
                    </div>
                    <div class="tittle-head" >
                        <h3 class="tittle" style="float: none;text-align: center;">2016 Winner </h3>
                        <br>
                        <div class="clearfix"></div>
                    </div>
                    <div style="max-height: 500px;float: right;">
                    <?php $__currentLoopData = $videos_latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vides): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                        <div class="col-md-3 content-grid" style="width: 70%">
                            <a href="<?php echo '/mypost?video='. $vides->id; ?>"><img src="<?php echo $vides->imageurl; ?>"
                                                                              title="Click To Play"><i class="fa fa-play"></i></a>
                            <div class="inner-info"><a href="<?php echo '/mypost?video='. $vides->id; ?>"><h5><?php echo e($vides->title); ?></h5></a></div>
                        </div>
                        

                        <div class="clearfix"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                <!-- //script for play-list -->
                </div>
                <!--//music-right-->
                <!-- /w3l-agile-its -->
            </div>
            <?php echo $__env->make('sponsor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1677.0819840144175!2d36.801393712555836!3d-1.297289714971404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f109521a475dd%3A0xb5070814ceb91e88!2sDaystar+University%2C+Nairobi+Campus!5e0!3m2!1sen!2ske!4v1485554800953"
                        width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <!--body wrapper start-->


        </div>
        <div class="clearfix"></div>
        <!--body wrapper end-->
        <!-- /w3l-agile -->

    </div>
    <!--body wrapper end-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.js"></script>
</body>
</html>