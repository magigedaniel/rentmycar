<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>New Post :: DAYSTAR RentMyCar.co.ke</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="js/jquery-2.1.4.js"></script>


</head>
<!-- /w3layouts-agile -->
<body class="sticky-header left-side-collapsed" onload="initMap()">
<section>
    <!-- left side start-->
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //signup -->
    <!-- /w3l-agile -->
    <!-- left side end-->
    <!-- main content start-->
    <div class="main-content">
        <!-- header-starts -->
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--notification menu end -->
        <!-- //header-ends -->
        <!-- /w3l-agileits -->
        <!-- //header-ends -->

        <div id="page-wrapper" style="">
            <!--body wrapper start-->
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/postvideo')); ?>" files ="true"  enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="vurl" class="col-md-4 control-label">Video Url</label>

                    <div class="col-md-6">
                        <input id="vurl" type="text" class="form-control" name="vurl" required autofocus>
                        <span style="font-size: 11px; color:red;"> (Upload video to Youtube and copy paste link here!)</span>

                    </div>
                </div>
                <div class="form-group">
                    <label for="vimage" class="col-md-4 control-label">Attach Front Image</label>

                    <div class="col-md-6">
                        <input type="file" class="form-control" name="vimage" id="vimage" required>
                        <span style="font-size: 11px; color:red;"> (image size for proper display use 257 by 257 pixel)</span>
                    </div>
                </div>



                <div class="form-group">
                    <label for="vdirector" class="col-md-4 control-label">Director</label>
                    <div class="col-md-6">
                        <input id="vdirector" type="text" class="form-control" name="vdirector"  autofocus>
                    </div>
                </div>
                <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
                <div class="form-group">
                    <label for="name" class="col-md-4 control-label">Video Title</label>

                    <div class="col-md-6">
                        <input id="cartitle" type="text" class="form-control" name="cartitle" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="car_content" class="col-md-4 control-label">Video Description </label>
                    <div class="col-md-6">
                        <textarea id="car_content" class="form-control" name="car_content"  autofocus rows="10"></textarea>
                    </div>
                </div>
                <script>
                    CKEDITOR.env.isCompatible = true;
                    CKEDITOR.replace( 'car_content' );
                    //                                config.removeDialogTabs = 'flash:advanced;image:Link';
                </script>
                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </div>
            </form>

        </div>
        <div class="clearfix"></div>
        <!--body wrapper end-->
        <!-- /w3l-agile -->
    </div>
    <!--body wrapper end-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.js"></script>
</body>
</html>