<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title><?php echo $video->title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="js/jquery-2.1.4.js"></script>


</head>

<style>
    div#page-wrapper{
        padding: 0 10% 0 10%;
    }
</style>
<!-- /w3layouts-agile -->
<body class="sticky-header left-side-collapsed">
<section>
    <!-- left side start-->
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /w3layouts-agile -->
    <!-- app-->
    <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog facebook" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="app-grids">
                        <div class="app">
                            <div class="col-md-5 app-left mpl">
                                <h3>DayStarFilm mobile app on your smartphone!</h3>
                                <p>Download and Avail Special Songs Videos and Audios.</p>
                                <div class="app-devices">
                                    <h5>Gets the app from</h5>
                                    <a href="#"><img src="images/1.png" alt=""></a>
                                    <a href="#"><img src="images/2.png" alt=""></a>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="col-md-7 app-image">
                                <img src="images/apps.png" alt="">
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //app-->
    <!-- /w3l-agile -->
    <!-- signup -->
<?php echo $__env->make('modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //signup -->
    <!-- /w3l-agile -->
    <!-- left side end-->
    <!-- main content start-->
    <div class="main-content">
        <!-- header-starts -->
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--notification menu end -->
        <!-- //header-ends -->
        <!-- /w3l-agileits -->
        <!-- //header-ends -->

        <div id="page-wrapper" style="">
            <div class="inner-content single">
                <!--/music-right-->

                <div class="single_left"><!--/video-main-->
                    <iframe width="100%" height="345px" src="<?php echo e($video->videoUrl); ?>?html5=1" allowfullscreen="" frameborder="0">
                    </iframe>

                    <!-- script for play-list -->

                    <!-- //script for play-list -->
                    <!--//video-main-->
                    <!-- /agileinfo -->
                    <h3 class="tittle"
                        style="background-color: red; font-size: 16px;color: white; float: right; border-radius: 20%;">
                        
                        <?php if($user !=null): ?>
                            <?php if($user->voted==1): ?>
                                <span> Thank you! You voted </span>

                            <?php else: ?>
                                <a href="vote?video=<?php echo $video->id; ?>" style="color: white;"> Click To vote Me</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="vote?video=<?php echo $video->id; ?>" style="color: white;"> Click To vote Me</a>
                        <?php endif; ?>

                    </h3>
               </div>
                <div class="response">
                    <h4><?php echo $video->title; ?></h4>
                    <div class="media response-info">
                        <div class="media-body response-text-right">
                            <?php echo $video->content; ?>

                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <!-- /agileits -->
                <!--//music-right-->
                <?php echo $__env->make('slidervideo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
            <!--body wrapper start-->


        </div>
        <div class="clearfix"></div>
        <!--body wrapper end-->
        <!-- /w3l-agile -->
    </div>
    <!--body wrapper end-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.js"></script>
</body>
</html>