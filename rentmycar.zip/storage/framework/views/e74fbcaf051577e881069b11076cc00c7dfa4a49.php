<div class="left-side sticky-left-side">

    <!--logo and iconic logo start-->
    <div class="logo">
        <h1><a href="/">DayStar<span>Film</span></a></h1>
    </div>
    <div class="logo-icon text-center">
        <a href="/">D </a>
    </div>
    <!-- /w3l-agile -->
    <!--logo and iconic logo end-->
    <div class="left-side-inner">

        <!--sidebar nav start-->
        <ul class="nav nav-pills nav-stacked custom-nav">
            <li class="active"><a href="/"><i class="lnr lnr-home"></i><span>Home</span></a></li>
            <li><a href="#"><i class="camera"></i> <span>Radio</span></a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal1"><i class="fa fa-th"></i><span>Apps</span></a></li>
            <li><a href="#"><i class="lnr lnr-music-note"></i> <span>Albums</span></a></li>
            <li><a href="#"><i class="lnr lnr-book"></i><span>Blog</span></a></li>
            <li class="menu-list"><a href="#"><i class="fa fa-thumb-tack"></i><span>Contact</span></a>
                <ul class="sub-menu-list">
                    <li><a href="#">Location</a> </li>
                </ul>
            </li>
        </ul>
        <!--sidebar nav end-->
    </div>
</div>