<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
    <head>
        <title>RentMyCar.co.ke  | Contact</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="keywords" content="RentMyCar.co.ke"/>
        <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
            }, false);
            function hideURLbar() {
            window.scrollTo(0, 1);
            } </script>
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
        <!-- Custom CSS -->
        <link href="css/style.css" rel='stylesheet' type='text/css'/>
        <!-- Graph CSS -->
        <link href="css/font-awesome.css" rel="stylesheet">
        <!-- jQuery -->
        <!-- lined-icons -->
        <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
        <!-- //lined-icons -->
        <!-- Meters graphs -->
        <script src="js/jquery-2.1.4.js"></script>
        <style>
            .red{
                color:red;
            }
            .form-area
            {
                background-color: #FAFAFA;
                padding: 10px 40px 60px;
                margin: 10px 0px 60px;
                border: 1px solid GREY;
            }
        </style>
    </head>

    <!-- /w3layouts-agile -->
    <body class="sticky-header left-side-collapsed">
        <section>
            <!-- left side start-->
            
            <!-- /w3layouts-agile -->
            <!-- app-->
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!-- //app-->
            <!-- /w3l-agile -->
            <!-- signup -->

            <!-- //signup -->
            <!-- /w3l-agile -->
            <!-- left side end-->
            <!-- main content start-->
            <div class="main-content" style="">
                <div style="" class="border-all">
                    <!-- header-starts -->
                    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!--notification menu end -->
                    <!-- //header-ends -->
                    <!-- /w3l-agileits -->
                    <!-- //header-ends -->
                    <div id="page-wrapper">
                        <div class="inner-content">
                        <p ><h2 style="text-align: center;"><em>We would love to hear from you!</em></h2></p>
                            <div class="container">
                                <div class="col-md-10">
                                    <div class="form-area">  
                                        <form role="form" action="/contact/email" method="post">
                                            <br style="clear:both">
                                            <h2 style="margin-bottom: 30px; text-align: center;">Contact Form</h2>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="email" name="email" placeholder="Email" required>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile Number" required>
                                            </div>
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                                            </div>
                                            <div class="form-group">
                                                <textarea class="form-control" type="textarea" id="message" placeholder="Message" maxlength="500" rows="10" name="message"></textarea>
                                                <span class="help-block"><p id="characterLeft" class="help-block ">You have reached the limit</p></span>                    
                                            </div>

                                            <button type="button" id="submit" name="submit" class="btn btn-primary pull-right">Submit Form</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <!--body wrapper end-->
                    <!-- /w3l-agile -->

                    <?php echo $__env->make('sponsor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div>

                        <div class="tittle-head">
                            <h3 class="tittle" style="text-align: center; margin-left: 35%;">Our Map Location</h3>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                        <div style="position: relative;">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1677.0819840144175!2d36.801393712555836!3d-1.297289714971404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f109521a475dd%3A0xb5070814ceb91e88!2sDaystar+University%2C+Nairobi+Campus!5e0!3m2!1sen!2ske!4v1485554800953"
                                    width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
            <!--body wrapper end-->

            <!--footer section end-->
            <!-- /w3l-agile -->
            <!-- main content end-->
        </section>

        <script src="js/jquery.nicescroll.js"></script>
        <script src="js/scripts.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.js"></script>
        <script>
        $(document).ready(function(){ 
    $('#characterLeft').text('500 characters left');
    $('#message').keydown(function () {
        var max = 500;
        var len = $(this).val().length;
        if (len >= max) {
            $('#characterLeft').text('You have reached the limit');
            $('#characterLeft').addClass('red');
            $('#btnSubmit').addClass('disabled');            
        } 
        else {
            var ch = max - len;
            $('#characterLeft').text(ch + ' characters left');
            $('#btnSubmit').removeClass('disabled');
            $('#characterLeft').removeClass('red');            
        }
    });    
});
    </script>
    </body>
</html>
