<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>RentMyCar.co.ke | Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="<?php echo e(asset('css/icon-font.css')); ?>" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="<?php echo e(asset('js/jquery-2.1.4.js')); ?>"></script>


</head>

<!-- /w3layouts-agile -->
<body class="sticky-header left-side-collapsed">
    
<section>
  
    <!--<div class="main-content" style="">-->
    <div class="container" style="">
        <div style="" class="border-all">
            <!-- header-starts -->
        <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--notification menu end -->
            <!-- //header-ends -->
            <!-- /w3l-agileits -->
            <!-- //header-ends -->
            <div id="page-wrapper">
                <div class="inner-content">
                        <h2 style="text-align: center; font-weight: 900;"><?php echo e($category_name); ?> </h2>
                        <div class="row">
                            <?php $__currentLoopData = $video_in_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video_archive1): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col-md-4">
                                            <!--<div class="caption">-->
                                                <h5 class="text-black text-sm" style="font-weight: 800; text-align: center"><?php echo e($video_archive1->title); ?></h5>
                                            <!--</div>-->
                                            <div class="thumbnail">
                                                <a href="<?php echo '/mypost?video='. $video_archive1->id.'&id='; ?>" target="_blank">
                                                    <img id="image<?php echo e($video_archive1->id); ?>" src="<?php echo e(asset("$video_archive1->imageurl")); ?>"  title="Click to Play" style="width:100%;" onmouseover="showVideo('<?php echo e($video_archive1->id); ?>')">
<!--                                                    <iframe width="100%" height="345px" src="<?php echo e($video_archive1->videoUrl); ?>?html5=1" allowfullscreen=""
                                                            frameborder="0" style="display: none" id="video<?php echo e($video_archive1->id); ?>">
                                                    </iframe>-->
                                                    <!--<div class="caption">-->
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <a href="<?php echo '/mypost?video='. $video_archive1->id.'&id='; ?>" target="_blank">
                                                                    <button type="button" class="btn btn-success btn-sm" id="btn-car"><span class="fa fa-play-circle"> Click to play now</span></button>
                                                                </a>
                                                            </div>
                                                        </div> 
                                                    <!--</div>-->
                                                </a>
                                            </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                        <?php echo e($video_in_category->links()); ?>

                </div>


                <!--body wrapper start-->


            </div>
            <div class="clearfix"></div>
            <!--body wrapper end-->
            <!-- /w3l-agile -->

            <?php echo $__env->make('sponsor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="clearfix"></div>
            <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <!--body wrapper end-->

    <!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="<?php echo e(asset('js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<div id="fb-root"></div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</body>
</html>
