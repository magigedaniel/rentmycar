<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>Support & Partner: Daystar East Africa Student Film Festival</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="js/jquery-2.1.4.js"></script>


</head>
<style>
    div#page-wrapper{
        padding: 0 10% 0 10%;
    }
</style>
<!-- /w3layouts-agile -->
<body class="sticky-header left-side-collapsed" onload="initMap()">
<section>
    <!-- left side start-->
<?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /w3layouts-agile -->
    <!-- app-->

    <!-- //app-->
    <!-- /w3l-agile -->
    <!-- signup -->
<?php echo $__env->make('modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- //signup -->
    <!-- /w3l-agile -->
    <!-- left side end-->
    <!-- main content start-->
    <div class="main-content">
        <!-- header-starts -->
    <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!--notification menu end -->
        <!-- //header-ends -->
        <!-- /w3l-agileits -->
        <!-- //header-ends -->

        <div id="page-wrapper" style="">
            <div class="inner-content single">
                <p style="text-align: center;"><strong>SUPPORT, PARTNERS & FOUNDING PARTNER</strong>
                    <br> <br><img src="images/p1.png" width="250"></p>
                <p><strong></strong></p><br>
                <br><br>
                <p style="text-align: center;"><strong><br>OUR PARTNERS</strong>
                    <br><img src="images/p2.jpg" width="250">
                <img src="images/p3.jpg" width="250">
                <img src="images/p4.png" width="250">
                </p>
                <br><br>
                <p><strong>DONATIONS</strong></p>
                <p><strong>RentMyCar.co.ke </strong>is a non-profit organization that relies on contributions from well-wishers keen to support the next generation of filmmakers.</p>
                <p>&nbsp;</p>
                <p>Contact us if you are interested in partnering with East Africa Student Film Festival.</p>
                <p>&nbsp;</p>
                <p>Email Emmanuel Wanyonyi, Festival Director at <a href="mailto:ewanyonyi@daystar.ac.ke">ewanyonyi@daystar.ac.ke</a> or <a href="mailto:ewanyonyi@deasff.com">ewanyonyi@deasff.com</a></p>
                <p>&nbsp;</p>
                <!-- /agileits -->
                <!--//music-right-->
                

            </div>
            <!--body wrapper start-->


        </div>
        <div class="clearfix"></div>
        <!--body wrapper end-->
        <!-- /w3l-agile -->
    </div>
    <!--body wrapper end-->
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.js"></script>
</body>
</html>