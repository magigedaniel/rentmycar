
<!--footer section start-->
<footer>
    <p>Copyright &copy; <?php echo date('Y');?> RentMyCar.co.ke. All Rights Reserved</p>
</footer>
