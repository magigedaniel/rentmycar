<?php
/**
 * Created by PhpStorm.
 * User: DMagige
 * Date: 10/27/2016
 * Time: 10:50 AM
 */
?>
<link rel="stylesheet" href="<?php echo e(asset ("/css/w3.css")); ?>">

<header class="main-header">

    <!-- Logo -->
    <a href="/admin" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>A</b>LT</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>Admin</b></span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="<?php echo e(asset ("/bower_components/AdminLTE/dist/img/user2-160x160.jpg")); ?>" class="user-image" alt="User Image">
                        <span class="hidden-xs"><?php echo e($user->fname.' '.$user->lname); ?> </span>
                        <span class="fa fa-caret-down"></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <img src="<?php echo e(asset ("/bower_components/AdminLTE/dist/img/user2-160x160.jpg")); ?>" class="img-circle" alt="User Image">

                            <p>
                                <?php echo e($user->fname.' '.$user->lname); ?> - <?php echo e($user->university); ?>

                                <small>Member since <?php echo e($user->created_at); ?></small>
                            </p>
                        </li>
                        <!-- Menu Body -->
                        <!--                        <li class="user-body">
                                                    <div class="row">
                                                        <div class="col-xs-4 text-center">
                                                            <a href="#">Followers</a>
                                                        </div>
                                                        <div class="col-xs-4 text-center">
                                                            <a href="#">Sales</a>
                                                        </div>
                                                        <div class="col-xs-4 text-center">
                                                            <a href="#">Friends</a>
                                                        </div>
                                                    </div>
                                                     /.row 
                                                </li>-->
                        <!-- Menu Footer-->
                        <li class="user-footer w3-animate-right w3-black">
                            <div class="pull-left">
                                <a href="/admin/users/profile/<?php echo e($user->id); ?>" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <!--<a href="<?php echo e(url('/logout')); ?>" class="btn btn-default btn-flat">Sign out</a>-->
                                <a href="<?php echo e(url('/logout')); ?>"  onclick="event.preventDefault();  document.getElementById('logout-form').submit();"
                                   class="btn btn-default btn-flat w3-text-gray" style="color: whitesmoke;" title="Click to Log out">
                                    Sign out
                                </a>
                                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>
