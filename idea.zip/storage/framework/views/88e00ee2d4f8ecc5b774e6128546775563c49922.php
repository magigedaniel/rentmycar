
<!--<style>
    .border-all{
        /*  border: solid 2px #9a9a9a;
          border-top: 0px;*/
        /*//box-shadow: 5px 5px 5px 5px #888888;*/
    }
    @media  handheld and (min-width: 1000px),
    screen and (min-width: 1000px) {
        .header-section {
            right: 10%;
            left: 10%
        }
    }
</style>
<div class="header-section" style="">
    <style>
        .menu{

            color: #ffffff;
            font-size: 16px;
            font-weight: bold;
        }
        @media  handheld and (min-width: 300px),
        screen and (min-width: 300px){
            .menu{
                margin-left: 2%;

            }

        }

    </style>
    <div style="padding-top: 1%; padding-bottom: 1%;">

        <a href="/" class="menu pull-left"><img src="images/EASFF-logo-small.png" style="float: left; "></a>
        <a href="/" class="menu">Home</a>
        <a href="/NewPost" class="menu">Submission</a>
        <a href="/about" class="menu">About</a>
        <a href="/archive" class="menu">Archive</a>
        <a href="/support" class="menu">Support & Partner</a>
        <a href="/contact" class="menu">Contact Us</a>
        <a href="/contact" class="menu">News</a>
        <a href="/faq" class="menu">FAQ</a>
        <?php if(!empty($user->fname)): ?>
        <?php if($user->usertype == "admin" || $user->usertype == "super-user"): ?>
        <a href="/admin" class="menu">Admin</a>
        <?php endif; ?>
        <?php endif; ?>
        <div id="loginpop" class="pull-right">
            <?php if(!empty($user->fname)): ?>
            <a href="<?php echo e(url('/logout')); ?>"
               onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();"
               class="" style="color: whitesmoke;" title="Click to Log out">
                Log out(<?php echo $user->fname; ?>)</a>
            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
            <?php else: ?>
            <a href="/login" id="" >
                <span style="">Login <i class="arrow glyphicon glyphicon-chevron-right"></i></span></a>
            <?php endif; ?>

        </div>
        ----
    </div>

</div>-->
<style>
    li a{
        color: #ffffff;
        /*font-size: 16px;*/
        font-weight: 500;
    }
    .icon-bar{
        background: #ffffff 
    }
</style>
<nav class="navbar" style="background: #9c1d1d;">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="border-color: black;color: #ffffff">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            
            <a class="navbar-brand" href="/" style="padding-top: 0px;padding-left: 0;float: left; margin-bottom: 5px"><img src="<?php echo e(asset('images/IMG_1203.PNG')); ?>"></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">

                <li><a href="/" class="active menu">Home</a></li>
                <li><a href="/NewPost" >Submission</a></li>
                <li><a href="/about" >About Us</a></li>
                <li> <a href="/archive" >Archive</a></li>
                <li> <a href="/support" >Support & Partner</a></li>
                <li> <a href="/contact" >Contact Us</a></li>
                <li> <a href="/faq" >FAQ</a>
                    <?php if(!empty($user->fname)): ?>
                    <?php if($user->usertype == "admin" || $user->usertype == "super-user"): ?>
                    <li><a href="/admin">Admin</a></li>
                    <?php endif; ?>
                    <?php endif; ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!--<li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>-->
                <?php if(!empty($user->fname)): ?>
                <li>
                    <a href="<?php echo e(url('/logout')); ?>"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                       class="glyphicon glyphicon-log-out">
                        Logout(<?php echo $user->fname; ?>)</a>
                </li>
                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
                <?php else: ?>
                <li><a href="/login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
