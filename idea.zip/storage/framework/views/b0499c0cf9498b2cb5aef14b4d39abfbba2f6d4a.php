<div class="footer">
    <div class="footer-grid">
        <h3>Navigation</h3>
        <ul class="list1">
            <li><a href="/">Home</a></li>
            <li><a href="#">All Songs</a></li>
            <li><a href="#">Albums</a></li>
            <li><a href="#">New Collections</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
    <div class="footer-grid">
        <h3>Our Account</h3>
        <ul class="list1">
            <li><a href="#" data-toggle="modal" data-target="#myModal5">Your Account</a></li>
            <li><a href="#">Personal information</a></li>
            <li><a href="#">Addresses</a></li>
            <li><a href="#">Discount</a></li>
            <li><a href="#">Orders history</a></li>
            <li><a href="#">Addresses</a></li>
            <li><a href="#">Search Terms</a></li>
        </ul>
    </div>
    <div class="footer-grid">
        <h3>Our Support</h3>
        <ul class="list1">
            <li><a href="#">Site Map</a></li>
            <li><a href="#">Search Terms</a></li>
            <li><a href="#">Advanced Search</a></li>
            <li><a href="#">Mobile</a></li>
            <li><a href="#">Contact Us</a></li>
            <li><a href="#">Mobile</a></li>
            <li><a href="#">Addresses</a></li>
        </ul>
    </div>
    <div class="footer-grid">
        <h3>Newsletter</h3>
        <p class="footer_desc">Nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
        <div class="search_footer">
            <form>
                <input type="text" placeholder="Email...." required="">
                <input type="submit" value="Submit">
            </form>
        </div>
    </div>
    <div class="footer-grid footer-grid_last">
        <h3>About Us</h3>
        <p class="footer_desc">Diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat enim ad minim veniam,.</p>
        <p class="f_text">Phone:  &nbsp;&nbsp;&nbsp;254 721 565 929</p>
        <p class="email">Email : &nbsp;<span><a href="mailto:info@magigedaniel.com">info@ourdomain.com</a></span></p>
    </div>
    <div class="clearfix"> </div>
</div>
<!--footer section start-->
<footer>
    <p>&copy 2016 - 2017 Daystar Film Festival. All Rights Reserved</p>
</footer>