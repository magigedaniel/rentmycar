<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>RentMyCar.co.ke | Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="RentMyCar.co.ke"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css'/>
    <!-- Custom CSS -->
    <link href="css/style.css" rel='stylesheet' type='text/css'/>
    <!-- Graph CSS -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- jQuery -->
    <!-- lined-icons -->
    <link rel="stylesheet" href="css/icon-font.css" type='text/css'/>
    <!-- //lined-icons -->
    <!-- Meters graphs -->
    <script src="js/jquery-2.1.4.js"></script>


</head>

<!-- /w3layouts-agile -->
<body class="sticky-header left-side-collapsed">
    
<section>
    <!-- left side start-->

<!-- /w3layouts-agile -->
    <!-- app-->



























<!-- //app-->
    <!-- /w3l-agile -->
    <!-- signup -->

    <!-- //signup -->
    <!-- /w3l-agile -->
    <!-- left side end-->
    <!-- main content start-->
    <!--<div class="main-content" style="">-->
    <div class="container" style="">
        <div style="" class="border-all">
            <!-- header-starts -->
        <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!--notification menu end -->
            <!-- //header-ends -->
            <!-- /w3l-agileits -->
            <!-- //header-ends -->
            <div id="page-wrapper">
                <div class="inner-content">

                    <div class="music-left">
                        <!--banner-section-->
                        <div class="banner-section">
                            <div class="banner">
                                <div class="callbacks_container">
                                    <ul class="rslides callbacks callbacks1" id="slider4">
                                    <?php $__currentLoopData = $front_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $front_image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <li>
                                            <div class="banner-img">
                                            <img src="<?php echo e($front_image->image_url); ?>" class="img-responsive" alt="">
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>    
                                    </ul>
                                </div>
                                <!--banner-->
                                <script src="js/responsiveslides.min.js"></script>
                                <script>
                                    // You can also use "$(window).load(function() {"
                                    $(function () {
                                        // Slideshow 4
                                        $("#slider4").responsiveSlides({
                                            auto: true,
                                            pager: true,
                                            nav: true,
                                            speed: 500,
                                            namespace: "callbacks",
                                            before: function () {
                                                $('.events').append("<li>before event fired.</li>");
                                            },
                                            after: function () {
                                                $('.events').append("<li>after event fired.</li>");
                                            }
                                        });

                                    });
                                </script>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <!--//End-banner-->
                        <!--albums-->
                        <!-- pop-up-box -->
                        <link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all">
                        <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
                        <script>
                            $(document).ready(function () {
                                $('.popup-with-zoom-anim').magnificPopup({
                                    type: 'inline',
                                    fixedContentPos: false,
                                    fixedBgPos: true,
                                    overflowY: 'auto',
                                    closeBtnInside: true,
                                    preloader: false,
                                    midClick: true,
                                    removalDelay: 300,
                                    mainClass: 'my-mfp-zoom-in'
                                });
                            });
                        </script>


                        <div class="albums second">
                            <div class="tittle-head">
                                <h4 style="font-weight: bold;color: black">RentMyCar.co.ke 6TH TO 11TH NOVEMBER 2017- DAYSTAR UNIVERSITY, NAIROBI, KENYA</h4>
                                <h4  id="demo"
                                    style="border: 2px solid #0B1C48;border-radius: 25px; padding: 5px;">                                                        
                                </h4>
                                <div class="clearfix"></div>
                            </div>
                            <div class="clearfix"></div>
                            <script>
                                // Set the date we're counting down to
                                var countDownDate = new Date("November 6, 2017 00:00:00").getTime();

                                // Update the count down every 1 second
                                var x = setInterval(function () {

                                    // Get todays date and time
                                    var now = new Date().getTime();

                                    // Find the distance between now an the count down date
                                    var distance = countDownDate - now;

                                    // Time calculations for days, hours, minutes and seconds
                                    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                                    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                                    // Output the result in an element with id="demo"
                                    document.getElementById("demo").innerHTML = days + "Days : " + hours + "Hrs : "
                                            + minutes + "Min : " + seconds + "sec " + " LEFT";

                                    // If the count down is over, write some text
                                    if (distance < 0) {
                                        clearInterval(x);
                                        document.getElementById("demo").innerHTML = "EXPIRED";
                                    }
                                }, 1000);
                            </script>

                        </div>


                        <!--//pop-up-box -->
                         
                          <h3 style="text-align: center">Current Video Submissions</h3>
                         <hr style="color: black; height: 3px">
                        <div  style="max-height: 1200px; overflow: scroll;">
                           
                            <?php
                            $ipaddress = '';
                            if (isset($_SERVER['HTTP_CLIENT_IP']))
                                $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
                            else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
                                $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
                            else if(isset($_SERVER['HTTP_X_FORWARDED']))
                                $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
                            else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
                                $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
                            else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
                                $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
                            else if(isset($_SERVER['HTTP_FORWARDED']))
                                $ipaddress = $_SERVER['HTTP_FORWARDED'];
                            else if(isset($_SERVER['REMOTE_ADDR']))
                                $ipaddress = $_SERVER['REMOTE_ADDR'];
                            else
                                $ipaddress = 'UNKNOWN';
                            //echo $ipaddress;
                            ?>
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_name => $video_in_category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <h4 style="text-align: center"><?php echo e($category_name); ?></h4>
                            <?php $__currentLoopData = $video_in_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vides): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-md-3 content-grid last-grid">
                                    <a href="<?php echo '/mypost?video='. $vides->id.'&id='.$ipaddress; ?>"><img
                                                src="<?php echo $vides->imageurl; ?>"
                                                title="Click to Play"><i
                                                class="fa fa-play"></i></a>
                                    <div class="inner-info"><a href="<?php echo '/mypost?video='. $vides->id.'&id='.$ipaddress; ?>">
                                            <h5><?php echo e($vides->title); ?></h5></a></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <a href="videos/category/<?php echo e($category_name); ?>"> <button type="button" class="btn btn-success btn-sm" style="margin-top: 10px"><span class="fa fa-plus-circle"> Click to view more <span style="color: black"><?php echo e($category_name); ?></span> videos</span></button>                </a>
                            <div class="clearfix"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            <div class="clearfix"></div>
                        </div>
                        <!--//End-albums-->
                        <!--//discover-view-->


                        <!--//discover-view-->
                    </div>
                    <!--//music-left-->
                    <!--/music-right-->
                    <div class="music-right">
                        <div style="padding-top: 5%" class="fb-page" data-href="https://www.facebook.com/weareeastafrica/" data-tabs="timeline" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/weareeastafrica/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/weareeastafrica/">Eastern Africa Students Film Festival</a></blockquote></div>
                       
                            <h4 style="float: none; text-align: center;">Our Partners</h4>
                            
                        <div style="max-height: 1000px; overflow: scroll;">
                           <div class="content-grid" style="width: 100%">
                            <?php $__currentLoopData = $partner_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="col col-sm-6">
                                    <iframe width="100%" height="150px" src="<?php echo e($video->videoUrl); ?>?html5=1"
                                            allowfullscreen="" frameborder="0">
                                    </iframe>
                                    <div class="inner-info" style="padding-right: 3px"><a href="<?php echo e($video->videoUrl); ?>" target="_blank">
                                            <h5><?php echo e($video->title); ?></h5></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                        </div>
                        <h4 style="float: none;text-align: center;">Participating Universities</h4>
                        <div style="max-height: 700px; overflow: scroll;">                            
                        <div class="content-grid" style="width: 100%">
                            <?php $__currentLoopData = $university_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="col col-sm-6">
                                    <iframe width="100%" height="150px" src="<?php echo e($video->videoUrl); ?>?html5=1"
                                            allowfullscreen="" frameborder="0">
                                    </iframe>
                                                <div class="inner-info"><a href="<?php echo e($video->videoUrl); ?>" target="_blank">
                                            <h5><?php echo e($video->title); ?></h5></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                           </div>
                        </div>
                        <!-- //script for play-list -->
                    </div>
                    <!--//music-right-->
                    <!-- /w3l-agile-its -->
                </div>


                <!--body wrapper start-->


            </div>
            <div class="clearfix"></div>
            <!--body wrapper end-->
            <!-- /w3l-agile -->

            <?php echo $__env->make('sponsor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div>

                <div class="tittle-head">
                    <h3 class="tittle" style="text-align: center; margin-left: 35%;">Our Map Location</h3>
                    <div class="clearfix"></div>
                </div>
                <div class="clearfix"></div>
                <div style="position: relative;">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1677.0819840144175!2d36.801393712555836!3d-1.297289714971404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f109521a475dd%3A0xb5070814ceb91e88!2sDaystar+University%2C+Nairobi+Campus!5e0!3m2!1sen!2ske!4v1485554800953"
                            width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="clearfix"></div>
            <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <!--body wrapper end-->

    <!--footer section end-->
    <!-- /w3l-agile -->
    <!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.js"></script>
<div id="fb-root"></div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
</body>
</html>
