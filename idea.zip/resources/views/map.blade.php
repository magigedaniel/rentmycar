<div>

    <div class="tittle-head">
        <h3 class="tittle" style="text-align: center; margin-left: 35%;">Our Map Location</h3>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
    <div style="position: relative;">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1677.0819840144175!2d36.801393712555836!3d-1.297289714971404!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f109521a475dd%3A0xb5070814ceb91e88!2sDaystar+University%2C+Nairobi+Campus!5e0!3m2!1sen!2ske!4v1485554800953"
                width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
</div>