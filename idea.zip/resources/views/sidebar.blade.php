{{--<div class="left-side sticky-left-side">--}}

    {{--<!--logo and iconic logo start-->--}}
    {{--<div class="logo">--}}
        {{--<h1><a href="/">DayStar<span style="color: red;">Film</span></a></h1>--}}
    {{--</div>--}}
    {{--<!-- /w3l-agile -->--}}
    {{--<!--logo and iconic logo end-->--}}
    {{--<div class="left-side-inner">--}}

        {{--<!--sidebar nav start-->--}}
        {{--<ul class="nav nav-pills nav-stacked custom-nav">--}}
            {{--<li class=""><a href="/"><span>Home</span></a></li>--}}
            {{--<li><a href="/NewPost"> <span>Submission</span></a></li>--}}
            {{--<li><a href="#"><span>About</span></a></li>--}}
            {{--<li><a href="#"><span>Archive</span></a></li>--}}
            {{--<li><a href="#"><span>Blog</span></a></li>--}}
            {{--<li class="menu-list"><a href="#"><span>Contact</span></a>--}}
                {{--<ul class="sub-menu-list">--}}
                    {{--<li><a href="#">Location</a> </li>--}}
                {{--</ul>--}}
            {{--</li>--}}
        {{--</ul>--}}
        {{--<!--sidebar nav end-->--}}
    {{--</div>--}}
{{--</div>--}}